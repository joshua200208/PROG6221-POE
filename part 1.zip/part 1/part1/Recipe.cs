﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace part1
{
    internal class Recipe
    {
 // -------------------Array of ingredients used in the recipe--------------------------------------
        public Ingredient[] Ingredients { get; set; }
        public string[] Steps { get; set; }

       
        public Recipe(Ingredient[] ingredients, string[] steps)
        {
            Ingredients = ingredients;
            Steps = steps;
        }

//------------------ Scales all ingredient quantities by the provided factor (0.5, 2, or 3)-------------------
        
        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Scale(factor);
            }
        }

        
 //--------------------Resets all ingredient quantities to their original values-----------------------------
        
        public void ResetRecipe()
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Reset();
            }
        }
      
  //----------------------------- Displays the whole recipe to user-----------------------------------
        
        public void DisplayRecipe()
        {
            Console.WriteLine("\n--- Recipe ---");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"- {ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }
            Console.WriteLine("\nSteps:");
            for (int i = 0; i < Steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}");
            }
            Console.WriteLine("--------------\n");
        }

        }
}
