﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE
{
    public class Ingredient
    {
        public string Name { get; set; }
        public string FoodGroup { get; set; }
        public double OriginalQuantity { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }

        public Ingredient(string name, string foodGroup, double quantity, string unit)
        {
            Name = name;
            FoodGroup = foodGroup;
            OriginalQuantity = quantity;
            Quantity = quantity;
            Unit = unit;
        }

        public override string ToString()
        {
            return $"{Quantity} {Unit} of {Name} ({FoodGroup})";
        }
    }
}
