﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE
{
    class RecipeRepository
    {
        private List<Recipe> _recipes = new List<Recipe>();

        public void AddRecipe(Recipe recipe)
        {
            _recipes.Add(recipe);
        }

        public IEnumerable<Recipe> GetAllRecipes()
        {
            return _recipes;
        }

        public void ClearAllRecipes()
        {
            _recipes.Clear();
        }
    }
}
