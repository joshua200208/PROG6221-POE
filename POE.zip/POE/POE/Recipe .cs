﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE
{
    internal class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public int OriginalCalories { get; set; }
        public int Calories { get; set; }
        public List<string> Instructions { get; set; }

        public Recipe(string name, int calories)
        {
            Name = name;
            OriginalCalories = calories;
            Calories = calories;
            Ingredients = new List<Ingredient>();
            Instructions = new List<string>();
        }

        public void AddIngredient(Ingredient ingredient)
        {
            Ingredients.Add(ingredient);
        }

        public void AddInstruction(string instruction)
        {
            Instructions.Add(instruction);
        }
        
        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity = ingredient.OriginalQuantity * factor;
            }
            Calories = (int)(OriginalCalories * factor);
        }
        
        public void ResetRecipe()
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity = ingredient.OriginalQuantity;
            }
            Calories = OriginalCalories;
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Recipe: {Name}");
            sb.AppendLine($"Calories: {Calories}");
            sb.AppendLine("Ingredients:");
            foreach (var ing in Ingredients)
            {
                sb.AppendLine(" - " + ing.ToString());
            }
            sb.AppendLine("Instructions:");
            foreach (var inst in Instructions)
            {
                sb.AppendLine(" - " + inst);
            }
            return sb.ToString();
        }
    }
}
