﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace POE
{
    /// <summary>
    /// Interaction logic for FilterRecipesPage.xaml
    /// </summary>
    public partial class FilterRecipesPage : Page
    {
        public FilterRecipesPage()
        {
            InitializeComponent();
            PopulateFoodGroups();
        }

        private void PopulateFoodGroups()
        {
// ------------------------------Get unique food groups from all recipes.-------------------------------------
            var foodGroups = AppData.RecipeRepository.GetAllRecipes()
                .SelectMany(r => r.Ingredients ?? Enumerable.Empty<Ingredient>())
                .Select(i => i.FoodGroup)
                .Where(fg => !string.IsNullOrEmpty(fg))
                .Distinct()
                .ToList();
            FoodGroupFilterComboBox.ItemsSource = foodGroups;
        }

        private void ApplyFilters_Click(object sender, RoutedEventArgs e)
        {
            var recipes = AppData.RecipeRepository.GetAllRecipes();
            var filteredRecipes = recipes;

            if (!string.IsNullOrWhiteSpace(IngredientFilterTextBox.Text))
            {
                filteredRecipes = filteredRecipes.Where(r => r.Ingredients != null &&
                    r.Ingredients.Any(i => i.Name.IndexOf(IngredientFilterTextBox.Text, StringComparison.OrdinalIgnoreCase) >= 0));
            }

            if (FoodGroupFilterComboBox.SelectedItem is string selectedFoodGroup)
            {
                filteredRecipes = filteredRecipes.Where(r => r.Ingredients != null &&
                    r.Ingredients.Any(i => string.Equals(i.FoodGroup, selectedFoodGroup, StringComparison.OrdinalIgnoreCase)));
            }

            if (int.TryParse(MaxCaloriesFilterTextBox.Text, out int maxCalories))
            {
                filteredRecipes = filteredRecipes.Where(r => r.Calories <= maxCalories);
            }

            FilteredRecipesListBox.ItemsSource = filteredRecipes.OrderBy(r => r.Name).ToList();
        }

    }
}
