﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE
{
    class AppData
    {
        public static RecipeRepository RecipeRepository { get; set; } = new RecipeRepository();

    }
}
