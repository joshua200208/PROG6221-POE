﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace part1
{
    internal class Ingredient
    {
        
            // Name of the ingredient.
            public string Name { get; set; }

            // The original quantity entered by the user.
            public double OriginalQuantity { get; set; }

            // The current quantity (can be scaled).
            public double Quantity { get; set; }

            // The unit of measurement (e.g., cups, tablespoons).
            public string Unit { get; set; }

            // The original calorie count for the ingredient.
            public int OriginalCalories { get; set; }

            // The current calorie count (can be scaled).
            public int Calories { get; set; }

            // The food group to which the ingredient belongs.
            public string FoodGroup { get; set; }

            /// <summary>
            /// Constructs an Ingredient with the specified details.
            /// </summary>
            /// <param name="name">Name of the ingredient.</param>
            /// <param name="quantity">Quantity of the ingredient.</param>
            /// <param name="unit">Unit of measurement.</param>
            /// <param name="calories">Calorie count for the given quantity.</param>
            /// <param name="foodGroup">Food group classification.</param>
            public Ingredient(string name, double quantity, string unit, int calories, string foodGroup)
            {
                Name = name;
                OriginalQuantity = quantity;
                Quantity = quantity;
                Unit = unit;
                OriginalCalories = calories;
                Calories = calories;
                FoodGroup = foodGroup;
            }

            /// <summary>
            /// Scales the ingredient's quantity and calories by the given factor.
            /// </summary>
            /// <param name="factor">Scaling factor (e.g., 0.5, 2, or 3).</param>
            public void Scale(double factor)
            {
                Quantity = OriginalQuantity * factor;
                // Scale calories (casting to int, which rounds down).
                Calories = (int)(OriginalCalories * factor);
            }

            /// <summary>
            /// Resets the ingredient's quantity and calories to their original values.
            /// </summary>
            public void Reset()
            {
                Quantity = OriginalQuantity;
                Calories = OriginalCalories;
            }
        }
    }




