﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace part1
{
    internal class Recipe
    {
//-----------------------Delegate for calorie warning notifications-----------------------------------------
      
        public delegate void CalorieWarningHandler(Recipe recipe, int totalCalories);

//-----------------------------------------------------------------------------------------------------------
            public string Name { get; set; }

            public List<Ingredient> Ingredients { get; set; }

            public List<string> Steps { get; set; }

            public event CalorieWarningHandler CalorieWarning;

            public Recipe(string name, List<Ingredient> ingredients, List<string> steps)
            {
                Name = name;
                Ingredients = ingredients;
                Steps = steps;
            }

           
            public void ScaleRecipe(double factor)
            {
                foreach (var ingredient in Ingredients)
                {
                    ingredient.Scale(factor);
                }
            }

  
            public void ResetRecipe()
            {
                foreach (var ingredient in Ingredients)
                {
                    ingredient.Reset();
                }
            }

 //--------------------Calculates the total calories of the recipes----------------------------------------
           
            public int CalculateTotalCalories()
            {
                int total = 0;
                foreach (var ingredient in Ingredients)
                {
                    total += ingredient.Calories;
                }
                return total;
            }

  // -----------------Displays the complete recipe details------------------------------------------------
           
            public void DisplayRecipe()
            {
                Console.WriteLine($"\n--- Recipe: {Name} ---");
                Console.WriteLine("Ingredients:");
                foreach (var ingredient in Ingredients)
                {
                    Console.WriteLine($"- {ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} " +
                                      $"({ingredient.Calories} calories, Food Group: {ingredient.FoodGroup})");
                }
                Console.WriteLine("\nSteps:");
                for (int i = 0; i < Steps.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {Steps[i]}");
                }

                int totalCalories = CalculateTotalCalories();
                Console.WriteLine($"\nTotal Calories: {totalCalories}");

 // -----------------show the calorie warning  if calories exceed 300----------------------------------------
                if (totalCalories > 300)
                {
                    CalorieWarning?.Invoke(this, totalCalories);
                }
                Console.WriteLine("--------------\n");
            }
        }
    }



